// Variable.h

#ifndef _VARIABLE_h
#define _VARIABLE_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "arduino.h"
#else
	#include "WProgram.h"
#endif

#include <MCUFRIEND_kbv.h>
#include <Adafruit_GFX.h> 




#endif

