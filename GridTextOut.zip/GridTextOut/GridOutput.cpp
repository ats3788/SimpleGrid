
#include "GridOutput.h"

void GridOutputClass::init(Adafruit_GFX * tft)
{
	_tft = tft;
	SetGrid();
}

void GridOutputClass::TextOut(char Text[], uint16_t X, uint16_t Y,const char A,const char B)
{
	
	uint8_t len = strlen(Text);
	Text[len ] = A;
	Text[len + 1] = B;
	Text[len + 2] = 0;

	len = strlen(Text);
	while (len < 8)
	{
		len = strlen(Text);
		Text[len] = ' ';
		Text[len + 1] = 0;
	}
	_tft->fillRect(X, Y -14, 86, 18, LCDBackgroud);
	_tft->setFont(&_times10pt_);
	_tft->setTextSize(1);
	_tft->setTextColor(TextColor, LCDBackgroud);
	_tft->setCursor(X, Y);
	_tft->print(Text);

}

void GridOutputClass::Int2Text(uint32_t Value, uint16_t height, char A, char B)
{
	static char str[10];
	itoa(Value, str, 10 );
	//strcpy(Buffer, Value2Text(millis()));
	TextOut(str, GridLineV +10, height, A, B);

}

void GridOutputClass::Float2Text(float Value, uint16_t height, char A, char B)
{
	static char str[10];
	 dtostrf(Value, 6,2, str);
	TextOut(str, GridLineV + 10, height, A, B);
}

void GridOutputClass::SetGrid()
{
	_tft->drawFastVLine(GridLineV, 0, 240, GridColor);
	_tft->drawFastHLine(GridLineV, GridLineH1, GridLineHW, GridColor);
	_tft->drawFastHLine(GridLineV, GridLineH2, GridLineHW, GridColor);
	_tft->drawFastHLine(GridLineV, GridLineH3, GridLineHW, GridColor);
	_tft->drawFastHLine(GridLineV, GridLineH4, GridLineHW, GridColor);
}

void GridOutputClass::RowTextOut(TextRow Row, uint32_t Value, char A, char B)
{
	uint16_t Zeile;
	switch (Row)
	{
	case Row1: Zeile = GridLineH1 - GridTextValue;
		break;
	case Row2: Zeile = GridLineH2 - GridTextValue;
		break;
	case Row3: Zeile = GridLineH3 - GridTextValue;
		break;
	case Row4: Zeile = GridLineH4 - GridTextValue;
		break;
	case Row5: Zeile = GridLineH5 - GridTextValue -10;
		break;
	default: Zeile = 0;
		break;
	}
	Int2Text(Value, Zeile, A, B);	
}

void GridOutputClass::RowTextOut(TextRow Row, float Value, char A, char B)
{
	uint16_t Zeile;
	switch (Row)
	{
	case Row1: Zeile = GridLineH1 - GridTextValue;
		break;
	case Row2: Zeile = GridLineH2 - GridTextValue;
		break;
	case Row3: Zeile = GridLineH3 - GridTextValue;
		break;
	case Row4: Zeile = GridLineH4 - GridTextValue;
		break;
	case Row5: Zeile = GridLineH5 - GridTextValue - 8;
		break;

	default: Zeile = 0;
		break;
	}
	Float2Text(Value, Zeile, A, B);
}

void GridOutputClass::RowTextOut(TextRow Row,const char Value[])
{
	uint16_t Zeile;
	switch (Row)
	{
	case Row1: Zeile = GridLineH1 - GridTextText;
		break;
	case Row2: Zeile = GridLineH2 - GridTextText;
		break;
	case Row3: Zeile = GridLineH3 - GridTextText;
		break;
	case Row4: Zeile = GridLineH4 - GridTextText;
		break;
	default: Zeile = 0;
		break;
	}
	TextOut(Value, GridLineV + 5, Zeile,0,0);
}
